import numpy as np 
def my_numpy_journey_arange(param_1, param_2, param_3):
    return np.arange(param_1,param_2,param_3)
    