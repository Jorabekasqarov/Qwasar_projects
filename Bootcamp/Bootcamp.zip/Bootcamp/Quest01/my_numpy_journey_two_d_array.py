import numpy as np 
def my_numpy_journey_two_d_array(param_1):
    x = np.array([[param_1],[param_1]])
    return x