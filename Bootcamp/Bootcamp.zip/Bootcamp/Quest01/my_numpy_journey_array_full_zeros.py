import numpy as np 
def my_numpy_journey_array_full_zeros(param_1, param_2):
    # x = np.zeros((3, 2))
    x = np.array([[param_1],[param_2]])
    x = np.zeros((param_1,param_2))
    return x