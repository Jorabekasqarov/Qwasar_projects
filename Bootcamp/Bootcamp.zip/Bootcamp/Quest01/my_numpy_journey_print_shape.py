def my_numpy_journey_print_shape(param_1):
    print(param_1.shape)