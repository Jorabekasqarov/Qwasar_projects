import numpy as np 
def my_numpy_journey_print_datatype(param_1):
    print(param_1.dtype)