import numpy as np 
def my_numpy_journey_sum(param_1):
    return np.sum(param_1)