import numpy as np 
import pandas as pd
def my_pandas_journey_missing_values(param_1):
    df = pd.DataFrame(param_1)
    return pd.isna(df)