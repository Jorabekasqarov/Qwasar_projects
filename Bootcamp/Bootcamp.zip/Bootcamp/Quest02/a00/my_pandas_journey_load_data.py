import pandas as pd 
def my_pandas_journey_load_data(param_1):
    c = pd.read_csv(param_1)
    return c