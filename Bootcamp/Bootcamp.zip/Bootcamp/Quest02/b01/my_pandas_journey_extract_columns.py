import pandas as pd 
def my_pandas_journey_extract_columns(param_1):
    return param_1.columns 


