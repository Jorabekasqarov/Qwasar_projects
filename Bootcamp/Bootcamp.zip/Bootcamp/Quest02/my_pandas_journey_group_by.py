import numpy as np 
import pandas as pd
def my_pandas_journey_group_by(param_1, param_2):